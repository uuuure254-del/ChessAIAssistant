package com.example.chessaiassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.argb(224, 25, 35, 50))
        }

        val header = TextView(this).apply {
            text = "♟ Chess AI  ⋮"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 12)
        }
        val body = TextView(this).apply {
            text = "โหมดฝึกซ้อม\nหน้าต่างนี้ลากย้ายได้\n\nตัววิเคราะห์กระดานจะเพิ่มในรุ่นถัดไป"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 12)
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val minimize = TextView(this).apply {
            text = "ย่อ"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(12, 8, 18, 8)
            setOnClickListener { body.visibility = if (body.visibility == View.GONE) View.VISIBLE else View.GONE }
        }
        val close = TextView(this).apply {
            text = "ปิด"
            textSize = 14f
            setTextColor(Color.rgb(255, 190, 190))
            setPadding(18, 8, 12, 8)
            setOnClickListener { stopSelf() }
        }
        actions.addView(minimize)
        actions.addView(close)
        box.addView(header)
        box.addView(body)
        box.addView(actions)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    wm.updateViewLayout(box, params)
                    true
                }
                else -> false
            }
        }

        panel = box
        wm.addView(box, params)
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
