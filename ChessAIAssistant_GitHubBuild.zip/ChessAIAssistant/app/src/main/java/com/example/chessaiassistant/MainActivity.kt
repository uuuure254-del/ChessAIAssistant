package com.example.chessaiassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val title = TextView(this).apply {
            text = "♟ Chess AI Assistant"
            textSize = 26f
            setTextColor(Color.rgb(25, 35, 50))
        }
        val info = TextView(this).apply {
            text = "ตัวช่วยหน้าต่างลอยสำหรับโหมดฝึกซ้อมและวิเคราะห์เกม\n\nเวอร์ชันเริ่มต้น: แสดงหน้าต่างลอยที่ลากย้ายและย่อได้"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 22, 0, 22)
        }
        val permission = Button(this).apply {
            text = "อนุญาตให้แสดงทับแอปอื่น"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
            }
        }
        val launch = Button(this).apply {
            text = "เปิดหน้าต่างลอย"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    permission.performClick()
                }
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(permission)
        layout.addView(launch)
        setContentView(layout)
    }
}
